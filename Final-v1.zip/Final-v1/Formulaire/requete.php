<?php 

require("../connexion_BDD.php");
session_start();

/*récup form préad*/
if (isset($_POST['pread'])) {
    $preadd = $_POST["choixhospi"];
    $datehospi = $_POST["datehospi"];
    $heurehopsi = $_POST["heurehospi"];
    $nompersonnel = $_POST['medecin'];  

    header("location: index.php");
    $_SESSION["form"] = 1;
}

/*récup form info Patien*/
if (isset($_POST['infoP'])) {
    $civ = $_POST["civ"];
    $nom = $_POST["nom"];
    $epouse = $_POST["epouse"];
    $prenom = $_POST["prenom"];
    $naissance = $_POST["naissance"];
    $adresse = $_POST["adresse"];
    $cp = $_POST["cp"];
    $ville = $_POST["ville"];
    $mail = $_POST["mail"];
    $tel = $_POST["tel"]; 

    header("location: index.php");
    $_SESSION["form"] = 2;
}

/*récup form info Assurance*/
if (isset($_POST['infoC'])) {
    $NomSecu = $_POST["NomSecu"];
    $NumSecu = $_POST["NumSecu"];
    $Assurance = $_POST["Assurance"];
    $ALD = $_POST["ALD"];
    $NomMutu = $_POST["NomMutu"];
    $NumAdherent = $_POST["NumAdherent"];
    $TypeChambre = $_POST["TypeChambre"];

    header("location: index.php");
    $_SESSION["form"] = 3;
}

/*récup form coords*/
if (isset($_POST['Coords'])) {
    $nomppre = $_POST["nomppre"];
    $prenomppre = $_POST["prenomppre"];
    $telppre = $_POST["telppre"];
    $adresseppre = $_POST["adresseppre"];

    $nomconf = $_POST["nomconf"];
    $prenomconf = $_POST["prenomconf"];
    $telconf = $_POST["telconf"];
    $adresseconf = $_POST["adresseconf"];

    $_SESSION["form"] = 4;
    header("location: index.php");
}

/*récup form pièce joint*/
if (isset($_POST['pieceJiont'])) {
    /*$CarteIdd = $_POST["CarteIdd"];
    $CarteVitale = $_POST["CarteVitale"];
    $CarteMutuel = $_POST["CarteMutuel"];
    $LivretFamille = $_POST["LivretFamille"];
    $DecisionJuge = $_POST["DecisionJuge"];
    $AutorisationSoin = $_POST["AutorisationSoin"];*/

    $_SESSION["form"] = 0;
    hospi();
}

/**************************ENVOIE A LA BDD ************************************* */
function affCiv() {
    $pdo = connexion_bdd();
    $sql="select Labelle from civ";
    $stmt=$pdo->query($sql);
    return $stmt;
}

function hospi() {
    $pdo = connexion_bdd();
    $sql="select * from couverturesociale";
    $stmt=$pdo->query($sql);
}
?>

